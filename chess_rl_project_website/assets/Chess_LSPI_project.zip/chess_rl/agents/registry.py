from __future__ import annotations

from pathlib import Path

from chess_rl.agents.base import Agent
from chess_rl.agents.random import RandomAgent
from chess_rl.agents.lspi_v1 import LSPIV1Agent
from chess_rl.agents.material_greedy import MaterialGreedyAgent
from chess_rl.agents.lspi_tactical import LSPITacticalAgent
from chess_rl.agents.lspi_search import LSPISearchAgent
from chess_rl.agents.material_minimax import MaterialMinimaxAgent


HUMAN = "Human"
LSPI_V10_SEARCH_200k = "LSPI v10.2 200k Search"
LSPI_V9_SEARCH_200k = "LSPI v9.2 200k Search"
LSPI_V8_SEARCH_200k = "LSPI v8.2 200k Search"
LSPI_V7_SEARCH_1M = "LSPI v7.2 1M Search"
LSPI_V6_SEARCH_200k = "LSPI v6.2 200k Search"
LSPI_V5_SEARCH_1M = "LSPI v5.2 1M Search" # center
LSPI_V5_SEARCH_200k = "LSPI v5.2 200k Search" #center
LSPI_V4_SEARCH_1M = "LSPI v4.2 Search"
LSPI_V4_TACTICAL_1M = "LSPI v4.1 Tactical"    
LSPI_V4_1M = "LSPI v4.0"    
LSPI_V3_SEARCH_1M = "LSPI v3.2 Search"
LSPI_V3_TACTICAL_1M = "LSPI v3.1 Tactical"    
LSPI_V3_1M = "LSPI v3.0"    
LSPI_V2_1M = "LSPI v2.0"    
LSPI_V1 = "LSPI v1"
MINIMAX = "Material minimax"
GREEDY = "Material greedy"
RANDOM = "Random legal"

# Adjust this path whenever you want to test a different checkpoint.
LSPI_V1_CHECKPOINT = Path("data/processed/checkpoints/lspi_v1_basic_pgn_200k_reg1e-1.npz")
LSPI_V2_CHECKPOINT = Path("data/processed/checkpoints/lspi_v2_1_basic_mix_pgn900k_anchor100k_reg1e-1.npz")
LSPI_V3_1M_CHECKPOINT = Path("data/processed/checkpoints/lspi_v3_basic_mix_pgn750k_anchor250k_reg1e-1.npz")
LSPI_V4_1M_CHECKPOINT = Path("data/processed/checkpoints/lspi_v4_slim_mix_pgn150k_anchor50k_reg1e-1.npz")
LSPI_V5_100k_CHECKPOINT = Path("data/processed/checkpoints/lspi_v5_center_mix_pgn135k_material50k_center15k_2000elo_reg1e-1.npz")
LSPI_V5_1M_CHECKPOINT = Path("data/processed/checkpoints/lspi_v5_center_mix_pgn650k_anchor250k_center100k_2000elo_reg1e-1.npz")
LSPI_V6_100k_CHECKPOINT = Path("data/processed/checkpoints/lspi_v6_attackmap_mix_pgn150k_anchor50k_2000elo_reg1e-1.npz")
LSPI_V7_1M_CHECKPOINT = Path("data/processed/checkpoints/lspi_v7_api_tactics_mix_pgn750k_anchor250k_2000elo_reg1e-1.npz")
LSPI_V8_200kCHECKPOINT = Path("data/processed/checkpoints/lspi_v8_api_tactics_clean_mix_pgn150k_anchor50k_2000elo_reg1e-1.npz")
LSPI_V9_200kCHECKPOINT = Path("data/processed/checkpoints/lspi_v9_response_tactics_mix_pgn150k_anchor50k_2000elo_reg1e-1.npz")
LSPI_V10_200kCHECKPOINT = Path("data/processed/checkpoints/lspi_v10_response_fast_mix_pgn150k_anchor50k_2000elo_reg1e-1.npz")

def player_options() -> list[str]:
    return [
        HUMAN,
        LSPI_V10_SEARCH_200k,
        LSPI_V9_SEARCH_200k,
        LSPI_V8_SEARCH_200k,
        LSPI_V7_SEARCH_1M,
        LSPI_V6_SEARCH_200k,
        LSPI_V5_SEARCH_200k,
        LSPI_V5_SEARCH_1M,
        LSPI_V4_SEARCH_1M,
        LSPI_V4_TACTICAL_1M,
        LSPI_V4_1M,
        LSPI_V3_SEARCH_1M,
        LSPI_V3_TACTICAL_1M,
        LSPI_V3_1M,
        LSPI_V1,
        MINIMAX,
        GREEDY,
        RANDOM,
    ]


def make_player(player_id: str) -> Agent | None:
    """
    Returns:
        None for human players.
        Agent instance for AI players.
    """
    if player_id == HUMAN:
        return None

    if player_id == RANDOM:
        return RandomAgent()

    if player_id == GREEDY:
        return MaterialGreedyAgent()

    if player_id == MINIMAX:
        return MaterialMinimaxAgent(
            depth=2,
            seed=1,
        )

    if player_id == LSPI_V1:
        if not LSPI_V1_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v1 checkpoint: {LSPI_V1_CHECKPOINT}")
        return LSPIV1Agent.load(str(LSPI_V1_CHECKPOINT))

    if player_id == LSPI_V3_1M:
        if not LSPI_V3_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v3 checkpoint: {LSPI_V3_1M_CHECKPOINT}")
        return LSPIV1Agent.load(str(LSPI_V3_1M_CHECKPOINT))

    if player_id == LSPI_V3_TACTICAL_1M:
        if not LSPI_V3_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v3 1M checkpoint: {LSPI_V3_1M_CHECKPOINT}")
        return LSPITacticalAgent.load(str(LSPI_V3_1M_CHECKPOINT))
    
    if player_id == LSPI_V3_SEARCH_1M:
        if not LSPI_V3_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v3 checkpoint: {LSPI_V3_1M_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V3_1M_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        ) 

    if player_id == LSPI_V4_1M:
        if not LSPI_V4_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v4 1M checkpoint: {LSPI_V4_1M_CHECKPOINT}")
        return LSPIV1Agent.load(str(LSPI_V4_1M_CHECKPOINT))

    if player_id == LSPI_V4_TACTICAL_1M:
        if not LSPI_V4_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v4 1M checkpoint: {LSPI_V4_1M_CHECKPOINT}")
        return LSPITacticalAgent.load(str(LSPI_V4_1M_CHECKPOINT))
    
    if player_id == LSPI_V4_SEARCH_1M:
        if not LSPI_V4_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v4 1M checkpoint: {LSPI_V4_1M_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V4_1M_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V5_SEARCH_200k:
        if not LSPI_V5_100k_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v5 100k checkpoint: {LSPI_V5_100k_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V5_100k_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V5_SEARCH_1M:
        if not LSPI_V5_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v5 1M checkpoint: {LSPI_V5_1M_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V5_1M_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V6_SEARCH_200k:
        if not LSPI_V6_100k_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v6 100k checkpoint: {LSPI_V6_100k_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V6_100k_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V7_SEARCH_1M:
        if not LSPI_V7_1M_CHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v7 1M checkpoint: {LSPI_V7_1M_CHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V7_1M_CHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V8_SEARCH_200k:
        if not LSPI_V8_200kCHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v8 200k checkpoint: {LSPI_V8_200kCHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V8_200kCHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )
        
    if player_id == LSPI_V9_SEARCH_200k:
        if not LSPI_V9_200kCHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v9 200k checkpoint: {LSPI_V9_200kCHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V9_200kCHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    if player_id == LSPI_V10_SEARCH_200k:
        if not LSPI_V10_200kCHECKPOINT.exists():
            raise FileNotFoundError(f"Missing LSPI v10 200k checkpoint: {LSPI_V10_200kCHECKPOINT}")

        return LSPISearchAgent.load(
            str(LSPI_V10_200kCHECKPOINT),
            depth=2,
            max_branch=None,
            use_draw_safety=True,
            use_tactical_safety=False,
        )

    raise ValueError(f"Unknown player: {player_id!r}")