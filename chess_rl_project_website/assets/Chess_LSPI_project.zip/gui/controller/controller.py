from __future__ import annotations
from typing import TYPE_CHECKING, Sequence
from dataclasses import dataclass

import pygame as pg
import pygame_gui as pgg

from gui.view.main_window import MainWindow
from chess_core.piece import Piece as p     
from chess_core.board import Board, BoardState
from chess_core.move import (
    Move,
    F_CASTLE,
    PROMO_NONE,
    PROMO_QUEEN,
    PROMO_ROOK,
    PROMO_BISHOP,
    PROMO_KNIGHT,
)

from chess_rl.agents.base import Agent
from chess_rl.agents.registry import HUMAN, player_options, make_player

# type-only, no runtime imports
# if TYPE_CHECKING:

@dataclass(frozen=True, slots=True)
class MoveRecord:
    move: Move
    mover_white: bool
    notation: str
    
class Controller:
    
    STOPPED: int = 0
    RUNNING: int = 1
    
    def __init__(self, ranks: int = 8, files: int = 8) -> None:
        self._state: int = self.RUNNING
        self._ranks: int = ranks
        self._files: int = files
        
        self._view: MainWindow = MainWindow(self, 800*2, 600*2, "Chess")
        self._model: Board     = Board(ranks, files)

        self._position_history: list[BoardState] = [self._model.get_state()]
        self._history_view_idx: int = 0  # 0=start position, len-1=current position
        
        self._white_player_id: str = HUMAN
        self._black_player_id: str = HUMAN
        self._white_agent: Agent | None = None
        self._black_agent: Agent | None = None

        self._agent_move_delay_ms: int = 250
        self._last_agent_move_ms: int = 0
        
        self._grid_size = self._ranks * self._files

        self._move_history: list[MoveRecord] = []
        self._last_move: Move | None = None
        
        self._sync_sidebar()

    def get_state(self) -> int:
        return self._state
    
    def update_state(self, state: int) -> None:
        self._state = state
        
    def get_ranks(self) -> int:
        return self._ranks
    
    def get_files(self) -> int:
        return self._files
    
    # TODO: Remove this and interact directly with controller
    def get_view(self) -> MainWindow:
        return self._view
    
    def get_pieces_on_board(self) -> Sequence[int]:
        return self._model.get_board()
    
    def get_piece_sprite(self, piece:int) -> str | None:
        color: str = "w" if p.is_white(piece) else "b"
        folder_path: str = "assets/pieces/"

        match p.piece_type(piece):
            case p.NONE:
                return None
            case p.PAWN:
                piece_type: str = "pawn-" + color + ".svg"
            case p.KNIGHT:
                piece_type: str = "knight-" + color + ".svg"
            case p.BISHOP:
                piece_type: str = "bishop-" + color + ".svg"
            case p.ROOK:
                piece_type: str = "rook-" + color + ".svg"
            case p.QUEEN:
                piece_type: str = "queen-" + color + ".svg"
            case p.KING:
                piece_type: str = "king-" + color + ".svg"
            case _:
                raise FileNotFoundError(f"Could find corresponding asset for piece: {piece}")
        return folder_path + piece_type

    def handle_event(self, event: pg.event.Event) -> None:
        
        self._view.manager_process_events(event)
        
        match event.type:
            case pg.QUIT:
                self._state = self.STOPPED
            
            case pg.KEYDOWN:
                match event.key:
                    case pg.K_q: # quit
                        self._state = self.STOPPED

                    case pg.K_f: # flip board
                        self.flip_board()

                    case pg.K_LEFT: # step back in history
                        self.history_previous()

                    case pg.K_RIGHT: # step forward in history
                        self.history_next()

                    case pg.K_UP: # step to latest/current position in history
                        self.history_latest()

                    case pg.K_DOWN: # step to first position in history
                        self.history_first()
            
            case pg.MOUSEMOTION:
                self._view.on_mouse_move(event.pos)
                
            case pg.MOUSEBUTTONDOWN:
                self._view.on_mouse_down(event.pos)
                
            case pg.MOUSEBUTTONUP:
                self._view.on_mouse_up(event.pos)
         
            case pgg.UI_BUTTON_PRESSED:
                sb = self._view._sidebar

                if event.ui_element == sb._new_game_button:
                    self.new_game(
                        white_player_id=sb.get_white_player_id(),
                        black_player_id=sb.get_black_player_id(),
                    )

                elif event.ui_element == sb._load_fen_button:
                    self.new_game(
                        sb.get_fen_text(),
                        white_player_id=sb.get_white_player_id(),
                        black_player_id=sb.get_black_player_id(),
                    )

                elif event.ui_element == sb._flip_board_button:
                    self.flip_board()

            case pgg.UI_TEXT_ENTRY_FINISHED:
                sb = self._view._sidebar
                if event.ui_element == sb._fen_entry:
                    self.new_game(
                        sb.get_fen_text(),
                        white_player_id=sb.get_white_player_id(),
                        black_player_id=sb.get_black_player_id(),
                    )

            case pg.VIDEORESIZE:
                x, y = event.size
                self._view.on_resize(x,y)
                    
    # For the agent: never call move_piece; always choose a full Move.
    def move_piece(self, source: int, destination: int) -> bool:
        """Attempt to move a piece from source square to destination square

        Args:
            source (int): source square index
            destination (int): destination square index

        Returns:
            bool: True if success, False if illegal move
        """
        cands = self.get_moves_to(source, destination, legal=True)
        if not cands:
            return False
        if len(cands) != 1:
            # promotion ambiguity etc. — GUI should call make_move() with chosen Move
            return False
        return self.make_move(cands[0])
    
    # TODO: SOS Cache legal moves since they are asked multiple times per second (each frame a square is highlighted)
    # def get_legal_moves(self, square: int) -> list[int]:
        # file, rank = self._model.idx_to_f_r(square)
        # return self._model.get_legal_moves(file, rank)
        # return self._model.get_legal_moves(square)
    
    def get_moves(self, src: int, legal: bool = True) -> list[Move]:
        if legal:
            return self._model.get_legal_moves(src)
        else:
            return self._model.get_pseudolegal_moves(src)

    def get_move_dests(self, src: int, legal: bool = True) -> list[int]:
        return [m.dst_square for m in self.get_moves(src, legal=legal)]
    
    def is_white_to_move(self) -> bool:
        return self._model.get_is_white_to_move()

    def is_friendly_piece(self, piece: int) -> bool:
        return piece != p.NONE and (p.is_white(piece) == self.is_white_to_move())

    def get_moves_to(self, src: int, dst: int, *, legal: bool = True) -> list[Move]:
        return [m for m in self.get_moves(src, legal=legal) if m.dst_square == dst]

    def make_move(self, move: Move) -> bool:
        # Do not allow moves from an old reviewed position.
        if self.is_reviewing_history():
            self._sync_sidebar(override_status="reviewing history; press Up to return to current position")
            return False

        mover_white = self._model.get_is_white_to_move()
        notation = self._format_move_notation(move)

        ok = self._model.make_move(move)
        if ok:
            self._last_move = move
            self._move_history.append(
                MoveRecord(
                    move=move,
                    mover_white=mover_white,
                    notation=notation,
                )
            )

            self._position_history.append(self._model.get_state())
            self._history_view_idx = len(self._position_history) - 1

            self._sync_sidebar()

        return ok

    def get_game_end_state(self) -> tuple[bool, str]:
        return self._model.game_end_state()

    def _castling_string(self) -> str:
        r = self._model._castling_rights  # bitmask
        s = ""
        if r & self._model.WHITE_CASTLE_KINGSIDE:  s += "K"
        if r & self._model.WHITE_CASTLE_QUEENSIDE: s += "Q"
        if r & self._model.BLACK_CASTLE_KINGSIDE:  s += "k"
        if r & self._model.BLACK_CASTLE_QUEENSIDE: s += "q"
        return s if s else "-"

    def get_debug_text(self) -> str:
        b = self._model
        turn = "White" if b.get_is_white_to_move() else "Black"

        ep = "-"
        if b._en_passant_target is not None:
            ep = b.idx_to_algebraic(b._en_passant_target)

        rep = b._rep_counts.get(b._zkey, 0)

        return (
            f"FEN:\n{b.to_fen()}\n"
            f"\nWhite player: {self._white_player_id}\n"
            f"Black player: {self._black_player_id}\n"
            f"\nTurn: {turn}\n"
            f"Castling: {self._castling_string()}  (mask={b._castling_rights:04b})\n"
            f"EP: {ep}\n"
            f"Halfmove: {b._halfmove_clock}\n"
            f"Zobrist: {b._zkey:#018x}\n"
            f"Repetition count (current): {rep}\n"
            f"\nHistory view: {self._history_view_idx}/{len(self._position_history) - 1}\n"
            f"Review mode: {self.is_reviewing_history()}\n"
        )

    def _sync_sidebar(self, *, override_status: str | None = None) -> None:
        done, reason = self._model.game_end_state()

        if override_status is not None:
            status = override_status
        elif self.is_reviewing_history():
            status = f"reviewing history: ply {self._history_view_idx}/{len(self._position_history) - 1}"
        else:
            status = "game over: " + reason if done else "playing"

        self._view._sidebar.set_status(status)
        self._view._sidebar.set_history(self.get_move_history_text())
        self._view._sidebar.set_debug(self.get_debug_text())

    def new_game(
        self,
        fen: str | None = None,
        *,
        white_player_id: str | None = None,
        black_player_id: str | None = None,
    ) -> bool:
        if white_player_id is not None or black_player_id is not None:
            ok = self.set_players(
                white_player_id or self._white_player_id,
                black_player_id or self._black_player_id,
            )
            if not ok:
                return False

        try:
            if fen and fen.strip():
                self._model.init_board(fen.strip())
            else:
                self._model.init_board()
        except ValueError as e:
            self._sync_sidebar(override_status=f"bad FEN: {e}")
            return False

        self._move_history.clear()
        self._last_move = None

        self._position_history = [self._model.get_state()]
        self._history_view_idx = 0

        self._last_agent_move_ms = pg.time.get_ticks()

        self._view._board.on_position_changed()
        self._sync_sidebar()
        return True

    def get_player_options(self) -> list[str]:
        return player_options()

    def set_players(self, white_player_id: str, black_player_id: str) -> bool:
        try:
            white_agent = make_player(white_player_id)
            black_agent = make_player(black_player_id)
        except Exception as e:
            self._sync_sidebar(override_status=f"player error: {e}")
            return False

        self._white_player_id = white_player_id
        self._black_player_id = black_player_id
        self._white_agent = white_agent
        self._black_agent = black_agent
        return True

    def is_human_turn(self) -> bool:
        if self.is_reviewing_history():
            return False
        return self._current_agent() is None

    def _current_agent(self) -> Agent | None:
        return self._white_agent if self._model.get_is_white_to_move() else self._black_agent

    def update(self) -> None:
        """
        Called once per frame. Lets agent players make a move when it is their turn.
        """
        if self.is_reviewing_history():
            return

        done, _reason = self._model.game_end_state()
        if done:
            return

        agent = self._current_agent()
        if agent is None:
            return

        now = pg.time.get_ticks()
        if now - self._last_agent_move_ms < self._agent_move_delay_ms:
            return

        self._last_agent_move_ms = now
        self._make_agent_move(agent)

    def _make_agent_move(self, agent: Agent) -> None:
        try:
            move = agent.pick_move(self._model)
        except Exception as e:
            self._sync_sidebar(override_status=f"agent error: {agent.info.name}: {e}")
            return

        ok = self.make_move(move)
        if not ok:
            self._sync_sidebar(override_status=f"agent illegal move: {agent.info.name}")
            return

        self._view._board.on_move_committed()

    def get_last_move(self) -> Move | None:
        # position_history[0] is the initial board, produced by no move.
        if self._history_view_idx <= 0:
            return None

        move_idx = self._history_view_idx - 1
        if move_idx >= len(self._move_history):
            return None

        return self._move_history[move_idx].move

    def _san_piece_letter(self, piece: int) -> str:
        match p.piece_type(piece):
            case p.KING:
                return "K"
            case p.QUEEN:
                return "Q"
            case p.ROOK:
                return "R"
            case p.BISHOP:
                return "B"
            case p.KNIGHT:
                return "N"
            case p.PAWN:
                return ""
            case _:
                return "?"

    def _san_promotion_letter(self, promotion: int) -> str:
        return {
            PROMO_QUEEN: "Q",
            PROMO_ROOK: "R",
            PROMO_BISHOP: "B",
            PROMO_KNIGHT: "N",
        }.get(promotion, "?")

    def _move_is_capture_before_move(self, move: Move) -> bool:
        """
        Return True if `move` is a capture in the current pre-move position.

        This also handles en-passant-style pawn captures where the destination
        square is empty but the pawn moves diagonally onto the EP target.
        """
        board_arr = self._model.get_board()

        moving_piece = int(board_arr[move.src_square])
        dst_piece = int(board_arr[move.dst_square])

        if dst_piece != p.NONE:
            return True

        # En passant: pawn moves diagonally to an empty en-passant target square.
        if p.piece_type(moving_piece) == p.PAWN:
            src_alg = self._model.idx_to_algebraic(move.src_square)
            dst_alg = self._model.idx_to_algebraic(move.dst_square)

            moved_diagonally = src_alg[0] != dst_alg[0]
            ep_target = getattr(self._model, "_en_passant_target", None)

            if moved_diagonally and ep_target == move.dst_square:
                return True

        return False

    def _san_disambiguation(self, move: Move, moving_piece: int) -> str:
        """
        SAN disambiguation for pieces.

        Examples:
          Nbd2
          R1e1
          Qh4e1 in rare full-disambiguation cases

        Pawns do not use this.
        """
        piece_type = p.piece_type(moving_piece)

        if piece_type in (p.PAWN, p.KING):
            return ""

        mover_white = p.is_white(moving_piece)

        alternatives: list[Move] = []

        for other in self._model.get_all_legal_moves():
            if other.src_square == move.src_square:
                continue

            if other.dst_square != move.dst_square:
                continue

            other_piece = int(self._model.get_board()[other.src_square])

            if other_piece == p.NONE:
                continue

            if p.is_white(other_piece) != mover_white:
                continue

            if p.piece_type(other_piece) != piece_type:
                continue

            alternatives.append(other)

        if not alternatives:
            return ""

        src_alg = self._model.idx_to_algebraic(move.src_square)
        src_file = src_alg[0]
        src_rank = src_alg[1:]

        alt_algs = [
            self._model.idx_to_algebraic(other.src_square)
            for other in alternatives
        ]

        same_file_exists = any(alg[0] == src_file for alg in alt_algs)
        same_rank_exists = any(alg[1:] == src_rank for alg in alt_algs)

        # PGN/SAN rule:
        # - if no same-type piece from the same file can also move there, use file
        # - else if no same-type piece from the same rank can also move there, use rank
        # - else use full square
        if not same_file_exists:
            return src_file

        if not same_rank_exists:
            return src_rank

        return src_alg

    def _san_check_suffix_after_move(self, move: Move) -> str:
        """
        Return '+', '#', or '' by temporarily applying the move.

        This must inspect the after-position, but the real board state must be
        restored before Controller.make_move() applies the move for real.
        """

        def suffix_from_current_after_position() -> str:
            done, reason = self._model.game_end_state()

            if done and reason == "checkmate":
                return "#"

            # After a legal move, side-to-move is the opponent.
            if self._model.in_check(self._model.get_is_white_to_move()):
                return "+"

            return ""

        # Prefer Board.temporary_move() if present.
        temporary_move = getattr(self._model, "temporary_move", None)
        if temporary_move is not None:
            with temporary_move(move):
                return suffix_from_current_after_position()

        # Fallback for older Board versions.
        state = self._model.get_state()
        ok = self._model.make_move(move)

        try:
            if not ok:
                return ""

            return suffix_from_current_after_position()

        finally:
            self._model.set_state(state)

    def _format_move_notation(self, move: Move) -> str:
        """
        Format a move in SAN-like PGN notation.

        Examples:
          e4
          Nf3
          Nbd2
          exd5
          Bxc6+
          O-O
          O-O-O
          e8=Q
          Qxe1#

        This is movetext SAN, not a full PGN file with headers.
        """
        moving_piece = int(self._model.get_board()[move.src_square])

        if moving_piece == p.NONE:
            return "?"

        src_alg = self._model.idx_to_algebraic(move.src_square)
        dst_alg = self._model.idx_to_algebraic(move.dst_square)

        # Castling.
        if move.flags & F_CASTLE:
            san = "O-O" if dst_alg[0] > src_alg[0] else "O-O-O"
            return san + self._san_check_suffix_after_move(move)

        piece_type = p.piece_type(moving_piece)
        is_capture = self._move_is_capture_before_move(move)

        # Pawn moves are special in SAN.
        if piece_type == p.PAWN:
            if is_capture:
                # Pawn captures include the source file: exd5
                san = f"{src_alg[0]}x{dst_alg}"
            else:
                san = dst_alg

            if move.promotion != PROMO_NONE:
                san += f"={self._san_promotion_letter(move.promotion)}"

            san += self._san_check_suffix_after_move(move)
            return san

        # Piece move.
        piece_letter = self._san_piece_letter(moving_piece)
        disambiguation = self._san_disambiguation(move, moving_piece)
        capture_text = "x" if is_capture else ""

        san = f"{piece_letter}{disambiguation}{capture_text}{dst_alg}"

        san += self._san_check_suffix_after_move(move)
        return san

    def get_move_history_text(self) -> str:
        if not self._move_history:
            return "(no moves yet)"

        lines: list[str] = []

        # Group as:
        # 1. e2e4 e7e5
        # 2. g1f3 ...
        
        # When viewing blacks first move:
        # 1. e2e4 >e7e5
        # 2. g1f3 ...
        for i in range(0, len(self._move_history), 2):
            move_no = i // 2 + 1

            white_marker = ">" if self._history_view_idx == i + 1 else " "
            black_marker = ">" if self._history_view_idx == i + 2 else " "

            white_move = f"{white_marker}{self._move_history[i].notation}"

            if i + 1 < len(self._move_history):
                black_move = f"{black_marker}{self._move_history[i + 1].notation}"
            else:
                black_move = ""

            lines.append(f"{move_no}. {white_move} {black_move}".rstrip())

        return "\n".join(lines)

    def is_reviewing_history(self) -> bool:
        return self._history_view_idx != len(self._position_history) - 1

    def _set_history_view_idx(self, idx: int) -> None:
        if not self._position_history:
            return

        idx = max(0, min(idx, len(self._position_history) - 1))
        if idx == self._history_view_idx:
            return

        self._history_view_idx = idx
        self._model.set_state(self._position_history[idx])

        self._view._board.on_position_changed()
        self._sync_sidebar()

    def history_previous(self) -> None:
        self._set_history_view_idx(self._history_view_idx - 1)

    def history_next(self) -> None:
        self._set_history_view_idx(self._history_view_idx + 1)

    def history_latest(self) -> None:
        self._set_history_view_idx(len(self._position_history) - 1)

    def history_first(self) -> None:
        self._set_history_view_idx(0)

    def flip_board(self) -> None:
        self._view._board.flip_board()

    def _pgn_result_string(self) -> str:
        """
        Return PGN result marker for the current/latest game state.
        """
        if not self._position_history:
            return "*"

        # Preserve review state if the user is browsing history.
        old_state = self._model.get_state()

        try:
            self._model.set_state(self._position_history[-1])

            done, reason = self._model.game_end_state()

            if not done:
                return "*"

            if reason == "checkmate":
                # Side to move is checkmated.
                return "0-1" if self._model.get_is_white_to_move() else "1-0"

            return "1/2-1/2"

        finally:
            self._model.set_state(old_state)
